package gestione.scuola;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



class ElencoSegreteriaTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	// valutare questo
	@Test
	void testAggiungiStudente() {
		ElencoSegreteria elenco = new ElencoSegreteria();
		Studente studente = new Studente("2024", "4B", 0,
				new Persona("Rossi", "Mario", "2005", "Luigi", "Anna", "Roma", "Roma", "Via Roma", 12345));

		elenco.aggiungiStudente(studente);

		assertEquals("Il numero di studenti nell'elenco non corrisponde", 1, elenco.getStudenti().size());
		assertEquals("Lo studente aggiunto non è lo stesso", studente, elenco.getStudenti().get(0));
	}

	@Test
	void testStart() {
		ElencoSegreteria test = new ElencoSegreteria(); // istanza

		boolean funzionante = test.Start();
		boolean valoreAtteso = true; // valore atteso

		assertEquals(funzionante, valoreAtteso);
	}
	
	//valuta questo
	@Test
	void TestCaricaDaFile() {
		Studente studente = new Studente("2024", "4B", 0,
				new Persona("Rossi", "Mario", "2005", "Luigi", "Anna", "Roma", "Roma", "Via Roma", 12345));
		ElencoSegreteria elenco = new ElencoSegreteria();
		elenco.aggiungiStudente(studente);
		
		String filePath = "testStudenti.bin";
		try {
			elenco.s.SalvaSuFile(elenco, filePath);
		} catch (IOException e) {
		}
		
		ElencoSegreteria elenco2 = new ElencoSegreteria();
		try {
			elenco2 = elenco.s.caricaDaFile(filePath);
		} catch (IOException e) {
		}
		
		assertEquals ("il numero di studenti nell'elenco non corrisponde", elenco.getStudenti().size(), elenco2.getStudenti().size());
	}
	
	@Test
	void TestSalvaSuFile() {
		ElencoSegreteria elenco = new ElencoSegreteria();
		assertThrows(Exception.class, () -> elenco.s.SalvaSuFile(elenco, "testStudenti.bin"));
	}
	
	
        
 
}
