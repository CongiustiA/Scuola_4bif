package gestione.scuola;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.LinkedList;
import gestione.salvataggio.*;

/**
 * classe Elenco segreteria per gestione dati degli studenti di una scuola
 * 
 * @author Alessandro Congiusti,Lorenzo Barteloni,Matteo Luvisi,Vincenzo
 *         Dellomargio
 * @version 1.0
 */
public class ElencoSegreteria implements java.io.Serializable {

	// attributi
	private LinkedList<Studente> studenti;
	Salvataggio s;

	/**
	 * istanzio un oggetto della classe ElencoSegreteria
	 */

	// metodo costruttore
	public ElencoSegreteria() {
		this.studenti = new LinkedList<Studente>();
	}

	/**
	 * restituisco il rierimento alla linkedList dell'eleco della segreteria
	 * 
	 * @return rierimento della linkedList
	 */

	// metodo get di Studenti
	public LinkedList<Studente> getStudenti() {
		return studenti;
	}

	/**
	 * imposto una linkedLista per l'elenco della segreteria
	 * 
	 * @param studenti - LinkedList che si vuole impostare
	 */

	// metodo set di Studenti
	private void setStudenti(LinkedList<Studente> studenti) {
		this.studenti = studenti;
	}

	/**
	 * richiedo l'inserimento dei dati dello studente da tastiere per nome, cognome,
	 * anno nascita, nome e/o cognome del padre dello studente, nome e/o cognome
	 * della madre dello studente, luogo di nascita, via di residenza, citta' di
	 * residenza, classe requentata, anno iscrizione e cap
	 * 
	 * @return un oggetto studente con i dati inseriti
	 */
	public Studente inputS() {

		Scanner s2 = new Scanner(System.in);

		System.out.println("inserisci il nome dello studente");
		String n = s2.nextLine();

		System.out.println("inserisci il cognome dello studente");
		String cog = s2.nextLine();

		System.out.println("inserisci l'anno di nascita dello studente");
		String an = s2.nextLine();

		System.out.println("inserisci il nome del padre dello studente");
		String p = s2.nextLine();

		System.out.println("inserisci il nome della madre dello studente");
		String m = s2.nextLine();

		System.out.println("inserisci il luogo di nascita dello studente dello studente");
		String ln = s2.nextLine();

		System.out.println("inserisci la via in cui vive lo studente");
		String v = s2.nextLine();

		System.out.println("inserisci la città dello studente");
		String c = s2.nextLine();

		System.out.println("inserisci la classe dello studente");
		String classe = s2.nextLine();

		System.out.println("inserisci l'anno d'iscrizione dello studente");
		String aI = s2.nextLine();

		int a = 0;

		System.out.println("inserisci il cap dello studente");
		int cap = s2.nextInt();

		Persona p1 = new Persona(cog, n, an, p, m, ln, c, v, cap);

		Studente st = new Studente(aI, classe, a, p1);

		return st;

	}

	/**
	 * aggiungo uno studente alla LinkedList
	 * 
	 * @param s - studente che si vuole aggiungere
	 */
	public void aggiungiStudente(Studente s) {

		this.studenti.addLast(s);

	}

	
	/**
	 * avvio il menu' della segreteria e chiedo che tipo di operazione si vuole fare
	 */
	public boolean Start() {

		boolean ris = false;

		String path = "studenti.bin";

		int n = 0;
		Scanner s = new Scanner(System.in);

		boolean stop = false;

		ElencoSegreteria temp = new ElencoSegreteria();

		try {
			temp = Salvataggio.caricaDaFile(path);
		} catch (FileNotFoundException e) {
			System.out.println("file non trovato");

			e.printStackTrace();

		} catch (IOException e) {
			System.out.println("input non valido");
			e.printStackTrace();
		}

		this.studenti = temp.studenti;

		while (stop == false) {

			System.out.println(
					"benvenuto nel menù della segreteria: per l'operazione desiderata scrivere"
					+ "1 se si vuole aggiungere uno studente, "
					+ "2 per salvare i dati, "
					+ "3 per stampara la lista degli studenti"
					+ "4 per chiudere il menù");
			n = s.nextInt();

			switch (n) {

			case 1: {

				Studente st = inputS();

				aggiungiStudente(st);
				ris = true;
				break;
			}
				

			case 2: {
				path = "studenti.bin";

				try {
					Salvataggio.SalvaSuFile(this, path);
					;
				} catch (Exception e) {

				}
				ris = true;
				break;
			}
			
			case 3: {
				System.out.println(toString());
				break;
			}

			case 4: {
				s.close();
				stop = true;
				ris = true;
				break;
				}
				
			
				default: {
					s.close();
					stop = true;
					ris = true;
				}
			}
			
		
		}
		return ris;

	}

	/**
	 *stampo ogni studente della lista
	 */
	@Override
	public String toString() {
		String ris = "Elenco Segreteria: \n";
		for (int i = 0; i < studenti.size(); i++)
			ris = ris + studenti.get(i).toString() + "\n";
		return ris;
	}
	
	/**
	 *confronto due oggetti ElencoSegreteria
	 */
	@Override
    public boolean equals(Object obj) {
        
        boolean stop=false;
        int i=0;
        
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ElencoSegreteria other = (ElencoSegreteria) obj;
        
        
        if(this.getStudenti().size()<other.getStudenti().size()) {
        
           while(stop==false && i<this.studenti.size()) {
            
              if(!this.studenti.get(i).equals(other.getStudenti().get(i))) {
                  stop=true;
                 return false;
              }
              else i++;
            }
        
        }
        else {
             while(stop==false && i<other.studenti.size()) {
                    
                  if(!this.studenti.get(i).equals(other.getStudenti().get(i))) {
                      stop=true;
                     return false;
                  }
                  else i++;
                }
        }
        return false;
    }

}
