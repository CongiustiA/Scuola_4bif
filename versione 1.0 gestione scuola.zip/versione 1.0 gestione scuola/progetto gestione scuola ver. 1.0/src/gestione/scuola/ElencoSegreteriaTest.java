package gestione.scuola;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ElencoSegreteriaTest {

	
		//valutare questo
	    @Test
	    void testAggiungiStudente() {
		
	      ElencoSegreteria elenco = new ElencoSegreteria();
	      Studente studente = new Studente("2024", "4B", 0,
	      new Persona("Rossi", "Mario", "2005", "Luigi", "Anna", "Roma", "Roma", "Via Roma", 12345));

	     elenco.aggiungiStudente(studente);

	     assertEquals("Il numero di studenti nell'elenco non corrisponde", 1, elenco.getStudenti().size());
	     assertEquals("Lo studente aggiunto non è lo stesso", studente, elenco.getStudenti().get(0));
	}
	
	//valuta questo
	@Test
    void TestCaricaDaFile() {
        Studente studente = new Studente("2024", "4B", 0,
                new Persona("Rossi", "Mario", "2005", "Luigi", "Anna", "Roma", "Roma", "Via Roma", 12345));
        ElencoSegreteria elenco = new ElencoSegreteria();
        elenco.aggiungiStudente(studente);

        String filePath = "testStudenti.bin";
        try {
            elenco.s.SalvaSuFile(elenco, filePath);
        } catch (IOException e) {
        }

        ElencoSegreteria elenco2 = new ElencoSegreteria();
        try {
            elenco2 = elenco.s.caricaDaFile(filePath);
        } catch (IOException e) {
        }

        assertEquals ("il numero di studenti nell'elenco non corrisponde", elenco.getStudenti().size(), elenco2.getStudenti().size());
    }

    @Test
    void TestSalvaSuFile() {
        ElencoSegreteria elenco = new ElencoSegreteria();
        assertThrows(Exception.class, () -> elenco.s.SalvaSuFile(elenco, "testStudenti.bin"));
    }

}
